from fastapi import FastAPI

app = FastAPI(title="FM Alarm Prediction API")

@app.get("/")
def root():
    return {
        "project": "FM Alarm Prediction",
        "status": "running"
    }

@app.get("/health")
def health():
    return {"status": "healthy"}

# TODO:
# POST /alarms
# POST /predict
# GET /topology/{cell_id}
# GET /impact/{cell_id}
