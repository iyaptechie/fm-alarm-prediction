# TODO: Convert alarm history into ML features.
#
# Example features:
# alarm_count_5min
# alarm_count_10min
# critical_count_10min
# packet_loss
# cpu_usage
# memory_usage
# ptp_sync_loss
#
# Target:
# cell_down_next_10min
