# TODO: Load trained model and predict CELL_DOWN probability.
