# TODO: Train the first Random Forest model.
#
# Recommended sequence:
# 1. Load historical alarms
# 2. Build features
# 3. Split train/test data
# 4. Train RandomForestClassifier
# 5. Evaluate precision, recall and F1
# 6. Save model under ml/model_registry/
