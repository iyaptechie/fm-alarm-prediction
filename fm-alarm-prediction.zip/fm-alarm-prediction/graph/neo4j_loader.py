# TODO: Load sites, nodes, cells and links into Neo4j.
# Suggested node labels:
# Site, GNB, CU, DU, Cell, Router
#
# Suggested relationships:
# HAS_GNB, HAS_CU, HAS_DU, HAS_CELL, CONNECTED_TO
