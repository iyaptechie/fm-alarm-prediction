"""Use Claude to generate human-readable RCA summaries from prediction + graph data."""

import os
import anthropic
from dotenv import load_dotenv

load_dotenv()

_client = None


def _get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise EnvironmentError("ANTHROPIC_API_KEY not set in .env")
        _client = anthropic.Anthropic(api_key=api_key)
    return _client


def explain_rca(prediction: dict, topology: dict) -> str:
    """
    Ask Claude to explain the root-cause analysis in plain English.

    Args:
        prediction: dict with keys like cell_id, probability, features
        topology: dict with keys like neighbours, upstream_nodes, paths
    Returns:
        Plain-English explanation string.
    """
    prompt = f"""You are a telecom network fault-management expert.

Prediction result:
- Cell ID     : {prediction.get('cell_id')}
- Down prob   : {prediction.get('probability', 0):.1%}
- Top features: {prediction.get('top_features', {})}

Graph topology context:
- Neighbours  : {topology.get('neighbours', [])}
- Upstream    : {topology.get('upstream_nodes', [])}
- Likely paths: {topology.get('paths', [])}

In 3–5 sentences explain:
1. Why this cell is likely to go down.
2. Which upstream node is the most probable root cause.
3. Which downstream cells / sites will be impacted.
Keep the language clear enough for a NOC operator."""

    message = _get_client().messages.create(
        model="claude-opus-5",
        max_tokens=512,
        messages=[{"role": "user", "content": prompt}],
    )
    return message.content[0].text
