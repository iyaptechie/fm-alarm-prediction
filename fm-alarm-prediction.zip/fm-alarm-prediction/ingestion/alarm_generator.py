# TODO: Generate synthetic telecom alarms.
# Suggested alarms:
# HIGH_CPU, HIGH_MEMORY, PACKET_LOSS, PTP_SYNC_LOSS,
# LINK_DOWN, CELL_UNAVAILABLE, DU_UNREACHABLE, GNB_UNREACHABLE

# Target relationship:
# precursor alarms -> CELL_UNAVAILABLE

if __name__ == "__main__":
    print("TODO: implement synthetic alarm generation")
