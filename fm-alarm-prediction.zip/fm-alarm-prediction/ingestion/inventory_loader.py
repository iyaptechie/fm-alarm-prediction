# TODO: Load CSV inventory and validate relationships.
