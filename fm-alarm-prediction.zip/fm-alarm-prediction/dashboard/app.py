import streamlit as st

st.title("FM Alarm Prediction")
st.write("TODO: Build telecom alarm prediction dashboard.")
