# TODO: Calculate potential service/cell impact from topology.
